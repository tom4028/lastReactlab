import React, { Component } from "react";
import AboutPage from "./components/AboutPage/AboutPage";
import ContactPage from "./components/ContactPage/ContactPage";
import HomePage from "./components/HomePage/HomePage";
import Menu from "./components/Menu/Menu";
import Footer from "./components/Footer/Footer";

//Import potrzebnyvh componentów

// import { HashRouter as Router, Route, Switch } from "react-router-dom";

//zmiana hashrouter na browser router
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import MoviesListPage from "./components/MoviesListPage/MoviesListPage";
import MovieDetailsPage from "./components/MovieDetailsPage.js/MovieDetailsPage";
class App extends Component {
  render() {
    return (
      <Router>
        <div>
          {/* Dodajemy menu do nawigacji strony */}
          <Menu />
          {/* Opakowujemy conponnetm switch zeby nie renderował ostatniego  pagenot found*/}
          <Switch>
            {/* Zamiana componentów w ścieźki routingu */}
            <Route exact path="/" component={HomePage} />
            {/* <HomePage /> */}
            <Route path="/about" component={AboutPage} />
            {/* <AboutPage /> */}
            <Route path="/contact" component={ContactPage} />
            {/* <ContactPage /> */}
            {/* doadajmeny listę filmów */}
            <Route path="/movies" component={MoviesListPage} />
            {/* dodajemy page not found */}
            {/* dodajemy detail spage */}
            <Route path="/movie/:id" component={MovieDetailsPage} />
            <Route render={() => <h1>Page not Found :(</h1>} />
          </Switch>
          <Footer />
        </div>
      </Router>
    );
  }
}

export default App;
