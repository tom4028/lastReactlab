import React from "react";
import { NavLink } from "react-router-dom";

// dodajemy style

const navStyle = {
  color: "red"
};
const Menu = () => (
  <div>
    <h4>Menu:</h4>
    <ul>
      <li>
        <NavLink exact to="/" activeStyle={navStyle}>
          Home
        </NavLink>
      </li>
      <li>
        <NavLink to="/about" activeStyle={navStyle}>
          About
        </NavLink>
      </li>
      <li>
        <NavLink to="/contact" activeStyle={navStyle}>
          Contact
        </NavLink>
      </li>
      <li>
        <NavLink to="/movies" activeStyle={navStyle}>
          Movies
        </NavLink>
      </li>
    </ul>
  </div>
);

export default Menu;
