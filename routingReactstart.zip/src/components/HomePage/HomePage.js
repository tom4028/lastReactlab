import React from "react";

const HomePage = () => (
  <div>
    <h3>Home Page</h3>
    <p>Hello world!</p>
  </div>
);

export default HomePage;
