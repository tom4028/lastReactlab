import React from "react";

import { Redirect } from "react-router-dom";
import MoviesService from "../../services/movies.service";

const MovieDetailsPage = props => {
  const movieId = props.match.params.id;
  const movie = MoviesService.getMovieById(movieId);

  //   inna wersja

  //   if (!movie) {
  //     //   lub props.history.replace("/movies") push wróci do ostaniego
  //     props.history.goBack();
  //     return null;
  //   }
  if (!movie) {
    return <Redirect to="/movies" />;
  }
  console.log(movie);
  return (
    <div>
      {/* dodajmey button powrotu do listy */}
      <button onClick={props.history.goBack}>Back to list</button>
      {/* <h3>Movie details {props.match.params.id}</h3> */}
      {/* dodajemy szczegóły do filmu */}
      <h3>Movie details {movieId}</h3>
      <h4>{movie.title}</h4>
      <img src={movie.poster} alt="poster" />
      <p>{movie.description}</p>
    </div>
  );
};

export default MovieDetailsPage;
