import React from "react";
import { Link } from "react-router-dom";

import MoviesService from "../../services/movies.service";

//Dodajmey ściżke do filu z id
const MoviesListPage = () => {
  const movies = MoviesService.getMovies();
  console.log(movies);
  return (
    <div>
      <h3>Movies List Page</h3>
      <ol>
        {movies.map(movie => (
          <li key={movie.id}>
            <Link to={`/movie/${movie.id}`}>{movie.title}</Link>
          </li>
        ))}
      </ol>
    </div>
  );
};

export default MoviesListPage;
