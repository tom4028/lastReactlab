import React from "react";

const Text = ({ text }) => <p>{text}</p>;

export default Text;
