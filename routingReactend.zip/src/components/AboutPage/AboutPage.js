import React from "react";

const AboutPage = () => (
  <div>
    <h3>About Page</h3>
    <p>
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed lacinia quam
      id justo hendrerit mollis. Sed feugiat erat ac tortor vehicula, et gravida
      ante tincidunt. Quisque iaculis urna a libero consequat rutrum. Proin orci
      felis, bibendum sit amet ex a, elementum pretium orci. Nunc et felis eu
      risus posuere sollicitudin sit amet a elit. Curabitur quis ex vitae odio
      rhoncus auctor consectetur vitae velit. Quisque sagittis, arcu nec
      convallis elementum, est odio luctus nisi, in pretium massa velit et eros.
      Nullam suscipit tortor vel justo tempus, accumsan auctor urna rutrum.
      Curabitur ut iaculis purus. Vestibulum euismod urna non leo vehicula
      tincidunt. Nullam nulla lacus, porttitor vitae facilisis quis, blandit sed
      leo. In mattis metus eu magna eleifend bibendum. Nam eget sapien ut nibh
      interdum aliquam. Nulla eget augue lorem.
    </p>
  </div>
);

export default AboutPage;
