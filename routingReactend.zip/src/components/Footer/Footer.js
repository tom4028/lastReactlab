import React from "react";
import { withRouter } from "react-router-dom";

//destruction ver const Footer = ({location}) = <p>You are here: {location.pathname</p>
//withRouter przekazyje do component history,location,match
const Footer = props => (
  <p className="red">You are here:{props.location.pathname}</p>
);

export default withRouter(Footer);
