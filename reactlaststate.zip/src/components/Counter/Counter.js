import React, { Component } from "react";

class Counter extends Component {
  // constructor() {
  //   super();
  //   this.state = {
  //     count: 0
  //   };
  //   this.handleClick = this.handleClick.bind(this);

  // }

  constructor() {
    super();
    console.log("constructor()");
  }
  state = {
    count: 0
  };

  handleClick = () => {
    this.setState(state => {
      return {
        count: state.count + 1
      };
    });
  };

  componentDidMount() {
    console.log("componentDidMount()");
  }

  componentDidUpdate(prevProps, prevState, snapshot) {
    console.log("componentDidUpdate");
  }
  shouldComponentUpdate(nextProps, nextState, nextCOntext) {
    console.log("shouldComponentUpdate");
    return nextState.count % 2 === 0;
  }

  componentWillUnmount() {
    console.log("componentWillUnmount()");
  }

  render() {
    const isDisabled = this.state.count >= 20;
    console.log("render()");
    return (
      <div>
        Clicks:{this.state.count}
        <button disabled={isDisabled} onClick={this.handleClick}>
          Click
        </button>
      </div>
    );
  }
}

export default Counter;
