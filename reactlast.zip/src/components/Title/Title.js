import React from "react";

const Title = ({ title }) => <h2>{title}</h2>;

export default Title;
