import React from "react";

const Image = ({ url }) => <img src={url} alt="" />;

export default Image;
