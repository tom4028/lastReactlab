import React, { Component } from "react";
import Counter from "./components/Counter/Counter";

class App extends Component {
  state = {
    counterIsVisble: true
  };

  showCounter = () => {
    this.setState({
      counterIsVisble: true
    });
  };
  hideCounter = () => {
    this.setState({
      counterIsVisble: false
    });
  };
  render() {
    return (
      <div>
        <button onClick={this.showCounter}>SHOW</button>
        <button onClick={this.hideCounter}>HIDE</button>
        {this.state.counterIsVisble && <Counter />}
      </div>
    );
  }
}

export default App;
